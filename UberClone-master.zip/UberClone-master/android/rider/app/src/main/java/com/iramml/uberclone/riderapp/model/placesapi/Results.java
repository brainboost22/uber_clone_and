package com.iramml.uberclone.riderapp.model.placesapi;

public class Results{
    public String formatted_address;
    public Geometry geometry;
    public int iconPlace=-1;

}
