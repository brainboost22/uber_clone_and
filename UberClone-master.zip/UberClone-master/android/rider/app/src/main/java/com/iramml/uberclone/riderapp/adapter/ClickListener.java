package com.iramml.uberclone.riderapp.adapter;

import android.view.View;

public interface ClickListener {
    void onClick(View view, int index);
}
