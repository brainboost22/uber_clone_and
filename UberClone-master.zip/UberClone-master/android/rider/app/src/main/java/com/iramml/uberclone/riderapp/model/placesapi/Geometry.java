package com.iramml.uberclone.riderapp.model.placesapi;

public class Geometry{
    public Location location;
}
