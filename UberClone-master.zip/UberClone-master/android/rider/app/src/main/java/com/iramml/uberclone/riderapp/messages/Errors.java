package com.iramml.uberclone.riderapp.messages;

public enum Errors {
    ERROR_LOGIN_GOOGLE,
    NOT_SUPPORT,
    WITHOUT_LOCATION,
    SENT_FAILED
}
