package com.iramml.uberclone.riderapp.model.placesapi;

public class Location{
    public String lat, lng;
}
