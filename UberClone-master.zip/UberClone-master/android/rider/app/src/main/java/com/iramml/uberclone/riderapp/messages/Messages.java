package com.iramml.uberclone.riderapp.messages;

public enum Messages {
    PERMISSION_DENIED,
    RATIONALE,
    REQUEST_SUCCESS
}
