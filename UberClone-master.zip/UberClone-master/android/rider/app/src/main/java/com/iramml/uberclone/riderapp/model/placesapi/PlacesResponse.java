package com.iramml.uberclone.riderapp.model.placesapi;

import java.util.ArrayList;

public class PlacesResponse {
    public ArrayList<Results> results;
}
