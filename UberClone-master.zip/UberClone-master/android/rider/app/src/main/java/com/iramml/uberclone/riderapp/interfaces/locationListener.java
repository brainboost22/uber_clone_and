package com.iramml.uberclone.riderapp.interfaces;

import com.google.android.gms.location.LocationResult;

public interface locationListener {
    void locationResponse(LocationResult response);
}
