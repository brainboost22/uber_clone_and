package com.iramml.uberclone.riderapp.common;

public class ConfigApp {
    public static final double baseFare = 2.55;
    public static final double timeRate = 0.35;
    public static final double distanceRate = 1.75;
    public static final String CLOUD_MESSAGING_SERVER_GEY = "AAAAF3zIV-w:APA91bHjuWHfpd5-8_ZTkYC4_atq8nmcfvYPxgt12cle0IbOW6YAFhaZ3nvLZQj2GK30FBGVMrpsl3-kcu-0OOOtbvJgtCIIMNoOvsJaoy-ulDlnDSsMQD4w5b9EeTMp1mTs6kHTyZcY";
    public static final String GOOGLE_API_KEY = "AIzaSyDfrhyZAZpsoVmz4NaVVJLZC91MINPGr9s";

}
