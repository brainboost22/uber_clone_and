package com.iramml.uberclone.riderapp.interfaces;

public interface HttpResponse {
    void httpResponseSuccess(String response);
}
