package com.iramml.uberclone.driverapp.interfaces;

import com.google.android.gms.location.LocationResult;

public interface locationListener {
    void locationResponse(LocationResult response);
}
