package com.iramml.uberclone.driverapp.model.fcm;

public class Notification {
    public String title;
    public String body;

    public Notification(String title, String body) {
        this.title = title;
        this.body = body;
    }
}
