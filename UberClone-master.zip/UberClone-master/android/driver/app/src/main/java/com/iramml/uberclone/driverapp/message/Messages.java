package com.iramml.uberclone.driverapp.message;

public enum Messages {
    PERMISSION_DENIED,
    RATIONALE,
    CANCELLED
}
