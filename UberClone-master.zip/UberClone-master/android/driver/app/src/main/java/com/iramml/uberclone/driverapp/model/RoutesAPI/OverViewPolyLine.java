package com.iramml.uberclone.driverapp.model.RoutesAPI;

public class OverViewPolyLine{
    public String points;
}
