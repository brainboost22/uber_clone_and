package com.iramml.uberclone.driverapp.model.RoutesAPI;

public class Steps{
    public LatLon start_location;
    public LatLon end_location;
}
