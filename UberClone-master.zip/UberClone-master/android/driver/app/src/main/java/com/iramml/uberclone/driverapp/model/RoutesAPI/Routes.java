package com.iramml.uberclone.driverapp.model.RoutesAPI;

import java.util.ArrayList;

public class Routes{
    public ArrayList<Legs> legs;
    public OverViewPolyLine overview_polyline=new OverViewPolyLine();
}
