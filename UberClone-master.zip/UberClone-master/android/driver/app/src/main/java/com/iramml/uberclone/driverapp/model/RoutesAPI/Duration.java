package com.iramml.uberclone.driverapp.model.RoutesAPI;

public class Duration {
    public String text;
}
