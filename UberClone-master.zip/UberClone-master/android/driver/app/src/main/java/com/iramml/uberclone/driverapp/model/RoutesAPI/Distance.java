package com.iramml.uberclone.driverapp.model.RoutesAPI;

public class Distance {
    public String text;
}
