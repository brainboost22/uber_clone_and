package com.iramml.uberclone.driverapp.adapter;

import android.view.View;

public interface ClickListener {
    void onClick(View view, int index);
}
