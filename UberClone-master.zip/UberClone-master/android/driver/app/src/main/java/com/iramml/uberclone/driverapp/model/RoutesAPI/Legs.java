package com.iramml.uberclone.driverapp.model.RoutesAPI;

import java.util.ArrayList;

public class Legs{
    public ArrayList<Steps> steps;
    public Duration duration;
    public Distance distance;
    public String end_address;
}
