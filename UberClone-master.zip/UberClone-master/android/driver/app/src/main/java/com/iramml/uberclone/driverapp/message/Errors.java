package com.iramml.uberclone.driverapp.message;

public enum Errors {
    ERROR_LOGIN_GOOGLE,
    NOT_SUPPORT,
    WITHOUT_LOCATION
}
